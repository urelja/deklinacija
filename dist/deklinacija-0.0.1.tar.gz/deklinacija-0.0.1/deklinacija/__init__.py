from deklinacija.module import genitiv, dativ, akuzativ, instrumental, lokativ, declineAll
from deklinacija.utils import toCyrillic
