import deklinacija as dek

print(dek.vokativ("Relja","male"))