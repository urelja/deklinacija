from deklinacija.module import genitiv, dativ, akuzativ, vokativ, instrumental, lokativ, declineAll
from deklinacija.utils import toCyrillic, toLatin
