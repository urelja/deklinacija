import deklinacija as dek

a = dek.posessiveAll("","male")

print(a)