from deklinacija.main import genitiv, dativ, akuzativ, vokativ, instrumental, lokativ, declineAll, possesive, posessiveAll
from deklinacija.utils import toCyrillic, toLatin, separateLetters, isLatin, Number, Gender 
